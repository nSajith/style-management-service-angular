export class Style {

    constructor(
      public styleCode: string,
      public status: string,
      public styleType: string,
      public styleName: string,
      public styleQuantity:string
    ) {  }
  
  }