export class StyleDetails {

    constructor(
      public itemCode: String,
      public itemCategory: {
        id: Number
      }
    //   public itemCode: string,
    //   public consumption: string
    ) {  }
  
  }